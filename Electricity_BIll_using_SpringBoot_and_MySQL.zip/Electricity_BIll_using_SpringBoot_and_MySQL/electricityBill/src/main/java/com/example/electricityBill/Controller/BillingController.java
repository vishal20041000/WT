package com.example.electricityBill.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.electricityBill.Entity.Billing;
import com.example.electricityBill.Entity.Consumer;
import com.example.electricityBill.Service.BillingService;

@RestController
@RequestMapping("/api")
public class BillingController {

    private final BillingService billingService;

    public BillingController(BillingService billingService) {
        this.billingService = billingService;
    }

    @PostMapping("/addConsumer")
    public ResponseEntity<Consumer> addConsumer(@RequestBody Consumer c) {
        return ResponseEntity.ok(billingService.addConsumer(c));
    }

    @GetMapping("/allConsumers")
    public ResponseEntity<List<Consumer>> getAllConsumers() {
        return ResponseEntity.ok(billingService.getAllConsumers());
    }

    @PostMapping("/generateBill/{consumerId}")
    public ResponseEntity<Billing> generateBill(@PathVariable Integer consumerId,
            @RequestParam int units) {
        return ResponseEntity.ok(billingService.generateBill(consumerId, units));
    }

    @GetMapping("/allBills")
    public ResponseEntity<List<Billing>> getAllBills() {
        return ResponseEntity.ok(billingService.getAllBills());
    }
    // @GetMapping("/Bill/{consumerId}")
    // public ResponseEntity<List<Billing>> getBillByConsumerId(@PathVariable
    // Integer consumerId) {
    // return ResponseEntity.ok(billingService.getBillByConsumerId(consumerId));
    // }
}
//http://localhost:8080/api/generateBill/1?units=120
//