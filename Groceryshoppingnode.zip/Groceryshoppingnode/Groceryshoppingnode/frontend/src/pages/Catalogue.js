import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Catalogue = () => {
    const [items, setItems] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:5000/api/items')
            .then(res => setItems(res.data))
            .catch(err => console.error(err));
    }, []);

    return (
        <div style={{ padding: 20 }}>
            <h2>Catalogue</h2>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 20 }}>
                {items.map(item => (
                    <div key={item.id} style={{ border: '1px solid #ccc', padding: 10, width: 200 }}>
                        <img src={item.image_url} alt={item.name} style={{ width: '100%', height: '150px' }} />
                        <h3>{item.name}</h3>
                        <p>₹{item.price}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Catalogue;
