import React from 'react';

const Home = () => (
    <div style={{ padding: 20 }}>
        <h1>Welcome to Online Grocery Shop</h1>
        <p>Fresh groceries at your fingertips!</p>
    </div>
);

export default Home;
