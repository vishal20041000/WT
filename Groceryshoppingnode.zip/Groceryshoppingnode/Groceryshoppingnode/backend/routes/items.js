const express = require('express');
const router = express.Router();
const db = require('../db');

// Fetch items
router.get('/items', (req, res) => {
    db.query('SELECT * FROM Items', (err, results) => {
        if (err) return res.status(500).json(err);
        res.status(200).json(results);
    });
});

module.exports = router;
