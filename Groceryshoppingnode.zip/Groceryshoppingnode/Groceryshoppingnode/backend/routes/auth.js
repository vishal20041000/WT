const express = require('express');
const router = express.Router();
const db = require('../db');

// Register
router.post('/register', (req, res) => {
    const { name, email, password } = req.body;
    db.query('INSERT INTO Consumer (name, email, password) VALUES (?, ?, ?)', [name, email, password],
        (err) => {
            if (err) return res.status(500).json(err);
            res.status(200).json("User registered");
        });
});

// Login
router.post('/login', (req, res) => {
    const { email, password } = req.body;
    db.query('SELECT * FROM Consumer WHERE email = ? AND password = ?', [email, password],
        (err, result) => {
            if (err) return res.status(500).json(err);
            if (result.length === 0) return res.status(401).json("Invalid credentials");
            res.status(200).json(result[0]);
        });
});

module.exports = router;
