const mysql = require('mysql2');
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Sncoll22bh', // your password
    database: 'grocery'
});
db.connect(err => {
    if (err) throw err;
    console.log("MySQL Connected");
});
module.exports = db;
