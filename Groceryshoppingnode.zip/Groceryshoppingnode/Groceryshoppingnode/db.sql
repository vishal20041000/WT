
-- Create database
CREATE DATABASE grocery;

-- Use database
USE grocery;

-- Consumer Table
CREATE TABLE Consumer (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255)
);

-- Items Table
CREATE TABLE Items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    price DECIMAL(10,2),
    image_url VARCHAR(255)
);

-- Sample Items
INSERT INTO Items (name, price, image_url) VALUES
('Tomatoes', 20.00, 'https://via.placeholder.com/150?text=Tomatoes'),
('Potatoes', 15.50, 'https://via.placeholder.com/150?text=Potatoes'),
('Milk', 50.00, 'https://via.placeholder.com/150?text=Milk');