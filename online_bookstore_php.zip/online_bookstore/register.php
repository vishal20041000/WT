<?php
include 'config.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $conn->real_escape_string(trim($_POST['username']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if username/email exists
    $check = $conn->query("SELECT * FROM users WHERE username='$username' OR email='$email'");
    if ($check->num_rows > 0) {
        $message = "Username or Email already exists.";
    } else {
        $insert = $conn->query("INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')");
        if ($insert) {
            header("Location: login.php");
            exit;
        } else {
            $message = "Registration failed. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Register - Online Book Store</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
<header>
    <h1>Register</h1>
</header>
<div class="container">
    <?php if ($message) echo "<p style='color:red;'>$message</p>"; ?>
    <form method="POST" action="register.php">
        <label>Username:</label>
        <input type="text" name="username" required />
        <label>Email:</label>
        <input type="email" name="email" required />
        <label>Password:</label>
        <input type="password" name="password" required />
        <button type="submit">Register</button>
    </form>
    <p>Already registered? <a href="login.php">Login here</a>.</p>
</div>
</body>
</html>
