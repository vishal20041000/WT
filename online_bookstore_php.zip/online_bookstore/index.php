<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Online Book Store - Home</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
<header>
    <h1>Welcome to the Online Book Store</h1>
    <nav>
        <a href="index.php">Home</a>
        <a href="catalogue.php">Catalogue</a>
        <?php if(isset($_SESSION['username'])): ?>
            <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php endif; ?>
    </nav>
</header>

<div class="container">
    <h2>Featured Books</h2>
    <?php
    $sql = "SELECT * FROM books LIMIT 3";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($book = $result->fetch_assoc()) {
            echo '<div class="book">';
            echo '<img src="' . htmlspecialchars($book['cover_image']) . '" alt="Cover">';
            echo '<div class="book-info">';
            echo '<h3>' . htmlspecialchars($book['title']) . '</h3>';
            echo '<p><strong>Author:</strong> ' . htmlspecialchars($book['author']) . '</p>';
            echo '<p><strong>Price:</strong> $' . number_format($book['price'], 2) . '</p>';
            echo '<p>' . htmlspecialchars($book['description']) . '</p>';
            echo '</div></div>';
        }
    } else {
        echo '<p>No books available.</p>';
    }
    ?>
</div>

</body>
</html>
