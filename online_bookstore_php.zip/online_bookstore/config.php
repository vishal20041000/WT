<?php
session_start();

$host = "localhost";
$user = "root";
$pass = "Sncoll22bh";  // your MySQL password
$dbname = "online_bookstore";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
