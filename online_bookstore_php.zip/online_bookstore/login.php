<?php
include 'config.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $conn->real_escape_string(trim($_POST['username']));
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM users WHERE username='$username'");
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            header("Location: catalogue.php");
            exit;
        } else {
            $message = "Invalid password.";
        }
    } else {
        $message = "Username not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Login - Online Book Store</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
<header>
    <h1>Login</h1>
</header>
<div class="container">
    <?php if ($message) echo "<p style='color:red;'>$message</p>"; ?>
    <form method="POST" action="login.php">
        <label>Username:</label>
        <input type="text" name="username" required />
        <label>Password:</label>
        <input type="password" name="password" required />
        <button type="submit">Login</button>
    </form>
    <p>New user? <a href="register.php">Register here</a>.</p>
</div>
</body>
</html>
