<?php
include 'config.php';

// Check login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Catalogue - Online Book Store</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
<header>
    <h1>Book Catalogue</h1>
    <nav>
        <a href="index.php">Home</a>
        <a href="catalogue.php">Catalogue</a>
        <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
    </nav>
</header>

<div class="container">
    <?php
    $sql = "SELECT * FROM books WHERE stock > 0";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($book = $result->fetch_assoc()) {
            echo '<div class="book">';
            echo '<img src="' . htmlspecialchars($book['cover_image']) . '" alt="Cover">';
            echo '<div class="book-info">';
            echo '<h3>' . htmlspecialchars($book['title']) . '</h3>';
            echo '<p><strong>Author:</strong> ' . htmlspecialchars($book['author']) . '</p>';
            echo '<p><strong>Price:</strong> $' . number_format($book['price'], 2) . '</p>';
            echo '<p>' . htmlspecialchars($book['description']) . '</p>';
            echo '<p><strong>Stock:</strong> ' . $book['stock'] . '</p>';
            echo '</div></div>';
        }
    } else {
        echo '<p>No books available in stock.</p>';
    }
    ?>
</div>

</body>
</html>
