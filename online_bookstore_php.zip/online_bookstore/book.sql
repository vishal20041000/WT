CREATE DATABASE online_bookstore;

USE online_bookstore;

CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255),
    price DECIMAL(8,2),
    stock INT,
    description TEXT,
    cover_image VARCHAR(255)
);

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
);

INSERT INTO books (title, author, price, stock, description, cover_image) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', 12.99, 10, 'A classic novel set in the Roaring Twenties.', 'covers/gatsby.jpg'),
('To Kill a Mockingbird', 'Harper Lee', 9.99, 15, 'A novel about racial injustice in the Deep South.', 'covers/mockingbird.jpg'),
('1984', 'George Orwell', 14.50, 5, 'Dystopian novel about totalitarian regime.', 'covers/1984.jpg');
