CREATE DATABASE electricity;
USE electricity;

CREATE TABLE Consumer (
    ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Address VARCHAR(200),
    MeterNumber VARCHAR(50),
    MobileNumber VARCHAR(15),
    Email VARCHAR(100)
);

CREATE TABLE Billing (
    ID INT PRIMARY KEY,
    Month VARCHAR(20),
    Year INT,
    UnitsUsed INT,
    BillAmount FLOAT,
    DueDate DATE
);