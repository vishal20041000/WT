CREATE DATABASE electricity_db;
USE electricity_db;

CREATE TABLE consumer (
    consumer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    address TEXT
);

CREATE TABLE billing (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,
    consumer_id INT,
    units_consumed INT,
    amount DECIMAL(10, 2),
    billing_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (consumer_id) REFERENCES consumer(consumer_id)
);