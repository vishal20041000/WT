<?php
// Database connection
$host = "localhost";
$user = "root";
$pass = "Sncoll22bh";
$dbname = "electricity_db";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Bill calculation function
function calculateBill($units) {
    $rate1 = 3.50; $rate2 = 4.00; $rate3 = 5.20; $rate4 = 6.50;
    $bill = 0;

    if ($units <= 50) {
        $bill = $units * $rate1;
    } elseif ($units <= 150) {
        $bill = (50 * $rate1) + (($units - 50) * $rate2);
    } elseif ($units <= 250) {
        $bill = (50 * $rate1) + (100 * $rate2) + (($units - 150) * $rate3);
    } else {
        $bill = (50 * $rate1) + (100 * $rate2) + (100 * $rate3) + (($units - 250) * $rate4);
    }

    return round($bill, 2);
}

// If form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $units = $_POST['units'];

    $amount = calculateBill($units);

    // Insert consumer
    $stmt = $conn->prepare("INSERT INTO consumer (name, address) VALUES (?, ?)");
    $stmt->bind_param("ss", $name, $address);
    $stmt->execute();
    $consumer_id = $stmt->insert_id;

    // Insert bill
    $stmt2 = $conn->prepare("INSERT INTO billing (consumer_id, units_consumed, amount) VALUES (?, ?, ?)");
    $stmt2->bind_param("iid", $consumer_id, $units, $amount);
    $stmt2->execute();

    // Display bill
    echo "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <title>Bill Generated</title>
        <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
    </head>
    <body>
    <div class='container mt-5'>
        <div class='card'>
            <div class='card-header bg-primary text-white'><h4>Electricity Bill</h4></div>
            <div class='card-body'>
                <p><strong>Consumer Name:</strong> $name</p>
                <p><strong>Address:</strong> $address</p>
                <p><strong>Units Consumed:</strong> $units</p>
                <p><strong>Total Amount:</strong> ₹$amount</p>
                <a href='electricity_bill.php' class='btn btn-secondary mt-3'>Calculate Another Bill</a>
            </div>
        </div>
    </div>
    </body>
    </html>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Electricity Bill Calculator</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center mb-4">Electricity Bill Calculator</h2>
    <form method="post" action="">
        <div class="form-group">
            <label>Consumer Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Address</label>
            <textarea name="address" class="form-control" required></textarea>
        </div>
        <div class="form-group">
            <label>Units Consumed</label>
            <input type="number" name="units" class="form-control" required min="1">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Calculate Bill</button>
    </form>
</div>
</body>
</html>