<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "Vishal@121";
$dbname = "electricity";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Bill calculation
function calculateBill($units) {
    if ($units <= 50) return $units * 3;
    elseif ($units <= 100) return (50 * 3) + (($units - 50) * 4);
    else return (50 * 3) + (50 * 4) + (($units - 100) * 5);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Electricity Billing System</title>
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Electricity Billing Form</h4>
            </div>
            <div class="card-body">
                <form method="post" action="">
                    <div class="row mb-3">
                        <div class="col">
                            <label>Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="col">
                            <label>Consumer ID</label>
                            <input type="number" class="form-control" name="id" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label>Address</label>
                        <input type="text" class="form-control" name="address" required>
                    </div>

                    <div class="row mb-3">
                        <div class="col">
                            <label>Meter Number</label>
                            <input type="text" class="form-control" name="meter" required>
                        </div>
                        <div class="col">
                            <label>Mobile Number</label>
                            <input type="text" class="form-control" name="mobile" required>
                        </div>
                        <div class="col">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col">
                            <label>Month</label>
                            <input type="text" class="form-control" name="month" required>
                        </div>
                        <div class="col">
                            <label>Year</label>
                            <input type="number" class="form-control" name="year" required>
                        </div>
                        <div class="col">
                            <label>Units Used</label>
                            <input type="number" class="form-control" name="units" id="units" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label>Due Date</label>
                        <input type="date" class="form-control" name="due_date" required>
                    </div>

                    <div class="mb-3">
                        <label><strong>Estimated Bill Amount (₹)</strong></label>
                        <input type="text" id="bill" class="form-control" readonly>
                    </div>

                    <button type="submit" name="submit" class="btn btn-primary">Generate Bill</button>
                </form>
            </div>
        </div>

        <?php
        if (isset($_POST['submit'])) {
            $name = $_POST['name'];
            $id = $_POST['id'];
            $address = $_POST['address'];
            $meter = $_POST['meter'];
            $mobile = $_POST['mobile'];
            $email = $_POST['email'];
            $month = $_POST['month'];
            $year = $_POST['year'];
            $units = $_POST['units'];
            $due_date = $_POST['due_date'];
            $billAmount = calculateBill($units);

            $consumerQuery = "INSERT INTO Consumer (ID, Name, Address, MeterNumber, MobileNumber, Email)
                              VALUES ('$id', '$name', '$address', '$meter', '$mobile', '$email')
                              ON DUPLICATE KEY UPDATE Name='$name', Address='$address', MeterNumber='$meter', MobileNumber='$mobile', Email='$email'";

            $billingQuery = "INSERT INTO Billing (ID, Month, Year, UnitsUsed, BillAmount, DueDate)
                             VALUES ('$id', '$month', '$year', '$units', '$billAmount', '$due_date')";

            if ($conn->query($consumerQuery) === TRUE && $conn->query($billingQuery) === TRUE) {
                echo "<div class='alert alert-success mt-3'>Total Bill for $units units: ₹<strong>$billAmount</strong><br>Due Date: $due_date</div>";
            } else {
                echo "<div class='alert alert-danger mt-3'>Error: " . $conn->error . "</div>";
            }

            $conn->close();
        }
        ?>
    </div>

    <!-- jQuery Script for Real-Time Bill Calculation -->
    <script>
        $('#units').on('input', function () {
            let units = parseInt($(this).val());
            let bill = 0;
            if (units <= 50) {
                bill = units * 3;
            } else if (units <= 100) {
                bill = (50 * 3) + ((units - 50) * 4);
            } else {
                bill = (50 * 3) + (50 * 4) + ((units - 100) * 5);
            }
            $('#bill').val(bill || '');
        });
    </script>
</body>
</html>