-- Create database
CREATE DATABASE electricity;

USE electricity;

-- Consumer Table
CREATE TABLE Consumer (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    units INT
);

-- Billing Table
CREATE TABLE Billing (
    id INT AUTO_INCREMENT PRIMARY KEY,
    consumer_id INT,
    bill_amount DECIMAL(10,2),
    FOREIGN KEY (consumer_id) REFERENCES Consumer(id)
);
