// routes/api.js
const express = require('express');
const router = express.Router();
const db = require('../db');

// Bill calculation function
function calculateBill(units) {
    let amount = 0;
    if (units <= 50) {
        amount = units * 3.5;
    } else if (units <= 150) {
        amount = (50 * 3.5) + ((units - 50) * 4);
    } else if (units <= 250) {
        amount = (50 * 3.5) + (100 * 4) + ((units - 150) * 5.2);
    } else {
        amount = (50 * 3.5) + (100 * 4) + (100 * 5.2) + ((units - 250) * 6.5);
    }
    return amount;
}

// POST API to insert data
router.post('/bill', (req, res) => {
    try {
        const { name, email, units } = req.body;

        if (!name || !email || typeof units !== 'number') {
            return res.status(400).json({ error: "Invalid input data format" });
        }

        const bill = calculateBill(units);

        const consumerQuery = `INSERT INTO Consumer (name, email, units) VALUES (?, ?, ?)`;
        db.query(consumerQuery, [name, email, units], (err, consumerResult) => {
            if (err) {
                console.error("Consumer Insert Error:", err);
                return res.status(500).json({ error: "Database error" });
            }

            const consumerId = consumerResult.insertId;
            const billingQuery = `INSERT INTO Billing (consumer_id, bill_amount) VALUES (?, ?)`;
            db.query(billingQuery, [consumerId, bill], (err) => {
                if (err) {
                    console.error("Billing Insert Error:", err);
                    return res.status(500).json({ error: "Database error" });
                }
                res.status(200).json({ message: "Bill calculated successfully", bill });
            });
        });
    } catch (error) {
        console.error("Error in Bill API:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

module.exports = router;
