package com.example.vit_result.vit_result.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Marks {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int subject1MSE, subject1ESE, subject2MSE, subject2ESE, subject3MSE, subject3ESE, subject4MSE, subject4ESE;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public int getSubject1MSE() { return subject1MSE; }
    public void setSubject1MSE(int subject1MSE) { this.subject1MSE = subject1MSE; }

    public int getSubject1ESE() { return subject1ESE; }
    public void setSubject1ESE(int subject1ESE) { this.subject1ESE = subject1ESE; }

    public int getSubject2MSE() { return subject2MSE; }
    public void setSubject2MSE(int subject2MSE) { this.subject2MSE = subject2MSE; }

    public int getSubject2ESE() { return subject2ESE; }
    public void setSubject2ESE(int subject2ESE) { this.subject2ESE = subject2ESE; }

    public int getSubject3MSE() { return subject3MSE; }
    public void setSubject3MSE(int subject3MSE) { this.subject3MSE = subject3MSE; }

    public int getSubject3ESE() { return subject3ESE; }
    public void setSubject3ESE(int subject3ESE) { this.subject3ESE = subject3ESE; }

    public int getSubject4MSE() { return subject4MSE; }
    public void setSubject4MSE(int subject4MSE) { this.subject4MSE = subject4MSE; }

    public int getSubject4ESE() { return subject4ESE; }
    public void setSubject4ESE(int subject4ESE) { this.subject4ESE = subject4ESE; }
}
