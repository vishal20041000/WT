package com.example.vit_result.vit_result.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.vit_result.vit_result.Model.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {}
