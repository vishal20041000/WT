package com.example.vit_result.vit_result.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.vit_result.vit_result.Model.Student;
import com.example.vit_result.vit_result.Service.StudentService;

import java.util.List;
@RestController
@RequestMapping("/students")
@CrossOrigin(origins = "http://localhost:3000")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    @PostMapping
    public Student createStudent(@RequestBody Student student) {
        return studentService.createStudent(student);
    }

    @PutMapping("/{id}")
    public Student updateStudent(@PathVariable Long id, @RequestBody Student student) {
        return studentService.updateStudent(id, student);
    }

    @DeleteMapping("/{id}")
    public void deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
    }

    @GetMapping("/calculate/{id}")
    public double calculateFinalScore(@PathVariable Long id) {
        return studentService.calculateFinalScore(id);
    }
}

/*
 * {
  "name": "John Doe",
  "marks": {
    "subject1MSE": 25,
    "subject1ESE": 60,
    "subject2MSE": 20,
    "subject2ESE": 55,
    "subject3MSE": 28,
    "subject3ESE": 65,
    "subject4MSE": 22,
    "subject4ESE": 50
  }
}

 */
