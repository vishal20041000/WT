package com.example.vit_result.vit_result.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.vit_result.vit_result.Model.Marks;
import com.example.vit_result.vit_result.Model.Student;
import com.example.vit_result.vit_result.Repository.StudentRepository;

import java.util.List;
@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student createStudent(Student student) {
        return studentRepository.save(student);
    }

    public Student updateStudent(Long id, Student updatedStudent) {
        return studentRepository.findById(id).map(student -> {
            student.setName(updatedStudent.getName());

            if (updatedStudent.getMarks() != null) {
                if (student.getMarks() == null) {
                    student.setMarks(updatedStudent.getMarks());
                } else {
                    // Update existing marks
                    student.getMarks().setSubject1MSE(updatedStudent.getMarks().getSubject1MSE());
                    student.getMarks().setSubject1ESE(updatedStudent.getMarks().getSubject1ESE());
                    student.getMarks().setSubject2MSE(updatedStudent.getMarks().getSubject2MSE());
                    student.getMarks().setSubject2ESE(updatedStudent.getMarks().getSubject2ESE());
                    student.getMarks().setSubject3MSE(updatedStudent.getMarks().getSubject3MSE());
                    student.getMarks().setSubject3ESE(updatedStudent.getMarks().getSubject3ESE());
                    student.getMarks().setSubject4MSE(updatedStudent.getMarks().getSubject4MSE());
                    student.getMarks().setSubject4ESE(updatedStudent.getMarks().getSubject4ESE());
                }
            }

            return studentRepository.save(student);
        }).orElseThrow(() -> new RuntimeException("Student not found with id: " + id));
    }

    public void deleteStudent(Long id) {
        if (!studentRepository.existsById(id)) {
            throw new RuntimeException("Student not found with id: " + id);
        }
        studentRepository.deleteById(id);
    }

    public double calculateFinalScore(Long studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found with id: " + studentId));

        Marks marks = student.getMarks();
        if (marks == null) throw new RuntimeException("Marks not found for student with id: " + studentId);

        double totalScore = ((marks.getSubject1MSE() * 0.3 + marks.getSubject1ESE() * 0.7) +
                             (marks.getSubject2MSE() * 0.3 + marks.getSubject2ESE() * 0.7) +
                             (marks.getSubject3MSE() * 0.3 + marks.getSubject3ESE() * 0.7) +
                             (marks.getSubject4MSE() * 0.3 + marks.getSubject4ESE() * 0.7)) / 4.0;

        return totalScore;
    }
}
