package com.example.vit_result.vit_result.Repository;

import com.example.vit_result.vit_result.Model.Marks;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MarksRepository extends JpaRepository<Marks, Long> {}
