import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function ResultApp() {
  const [students, setStudents] = useState([]);
  const [name, setName] = useState('');
  const [marks, setMarks] = useState({
    subject1MSE: 0, subject1ESE: 0,
    subject2MSE: 0, subject2ESE: 0,
    subject3MSE: 0, subject3ESE: 0,
    subject4MSE: 0, subject4ESE: 0
  });
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const response = await axios.get('http://localhost:8080/students');
      setStudents(response.data);
    } catch (error) {
      console.error('Failed to fetch students:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const studentData = { name, marks };

    try {
      if (editingId) {
        // Update existing student
        await axios.put(`http://localhost:8080/students/${editingId}`, studentData);
      } else {
        // Create new student
        await axios.post('http://localhost:8080/students', studentData);
      }
      resetForm();
      fetchStudents();
    } catch (error) {
      console.error('Failed to save student:', error);
    }
  };

  const resetForm = () => {
    setName('');
    setMarks({
      subject1MSE: 0, subject1ESE: 0,
      subject2MSE: 0, subject2ESE: 0,
      subject3MSE: 0, subject3ESE: 0,
      subject4MSE: 0, subject4ESE: 0
    });
    setEditingId(null);
  };

  const handleEdit = (student) => {
    setEditingId(student.id);
    setName(student.name);
    setMarks({
      subject1MSE: student.marks?.subject1MSE ?? 0,
      subject1ESE: student.marks?.subject1ESE ?? 0,
      subject2MSE: student.marks?.subject2MSE ?? 0,
      subject2ESE: student.marks?.subject2ESE ?? 0,
      subject3MSE: student.marks?.subject3MSE ?? 0,
      subject3ESE: student.marks?.subject3ESE ?? 0,
      subject4MSE: student.marks?.subject4MSE ?? 0,
      subject4ESE: student.marks?.subject4ESE ?? 0,
    });
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this student?')) {
      try {
        await axios.delete(`http://localhost:8080/students/${id}`);
        fetchStudents();
        // If deleting the student currently being edited, reset form
        if (editingId === id) {
          resetForm();
        }
      } catch (error) {
        console.error('Failed to delete student:', error);
      }
    }
  };

  return (
    <div className="app-container">
      <h1>VIT Semester Result Management</h1>
      <form onSubmit={handleSubmit} className="student-form">
        <input
          type="text"
          placeholder="Student Name"
          value={name}
          onChange={e => setName(e.target.value)}
          required
        />
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="subject-group">
            <label>Subject {i} MSE:</label>
            <input
              type="number"
              value={marks[`subject${i}MSE`]}
              onChange={e => setMarks(prev => ({
                ...prev,
                [`subject${i}MSE`]: Number(e.target.value)
              }))}
              min={0} max={30}
              required
            />
            <label>Subject {i} ESE:</label>
            <input
              type="number"
              value={marks[`subject${i}ESE`]}
              onChange={e => setMarks(prev => ({
                ...prev,
                [`subject${i}ESE`]: Number(e.target.value)
              }))}
              min={0} max={70}
              required
            />
          </div>
        ))}
        <div className="form-buttons">
          <button type="submit">{editingId ? 'Update Student' : 'Add Student'}</button>
          {editingId && (
            <button type="button" onClick={resetForm} className="cancel-btn">Cancel</button>
          )}
        </div>
      </form>

      <div className="student-list">
        <h2>Students List</h2>
        {students.length === 0 ? (
          <p>No students found.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Name</th>
                {[1, 2, 3, 4].map(i => (
                  <React.Fragment key={i}>
                    <th>S{i} MSE (30%)</th>
                    <th>S{i} ESE (70%)</th>
                    <th>S{i} Final</th>
                  </React.Fragment>
                ))}
                <th>Total Marks</th>
                <th>Percentage</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {students.map(student => {
                const m = student.marks || {};

                const finalMarks = [1, 2, 3, 4].map(i =>
                  Math.round(
                    (m[`subject${i}MSE`] ?? 0) * 0.3 +
                    (m[`subject${i}ESE`] ?? 0) * 0.7
                  )
                );
                const total = finalMarks.reduce((a, b) => a + b, 0);
                const maxTotal = 100 * 4;
                const percentage = ((total / maxTotal) * 100).toFixed(2);

                return (
                  <tr key={student.id}>
                    <td>{student.name}</td>
                    {[1, 2, 3, 4].map(i => (
                      <React.Fragment key={i}>
                        <td>{m[`subject${i}MSE`] ?? 0}</td>
                        <td>{m[`subject${i}ESE`] ?? 0}</td>
                        <td>{finalMarks[i - 1]}</td>
                      </React.Fragment>
                    ))}
                    <td>{total}</td>
                    <td>{percentage}%</td>
                    <td>
                      <button onClick={() => handleEdit(student)} className="edit-btn">Edit</button>
                      <button onClick={() => handleDelete(student.id)} className="delete-btn">Delete</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default ResultApp;
