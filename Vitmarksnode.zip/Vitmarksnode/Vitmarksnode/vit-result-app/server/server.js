const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Sncoll22bh', // <-- your MySQL password
  database: 'vit_results'
});

db.connect(err => {
  if (err) throw err;
  console.log("MySQL connected...");
});

app.get('/results', (req, res) => {
  const sql = `
    SELECT s.student_id, s.name, s.roll_number, 
           m.subject, m.marks AS mse_marks, 
           e.marks AS ese_marks,
           ROUND(m.marks * 0.3 + e.marks * 0.7, 2) AS total_marks
    FROM students s
    JOIN mse m ON s.student_id = m.student_id
    JOIN ese e ON s.student_id = e.student_id AND m.subject = e.subject
    ORDER BY s.student_id, m.subject;
  `;
  db.query(sql, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

app.listen(3001, () => {
  console.log("Server running at http://localhost:3001");
});
