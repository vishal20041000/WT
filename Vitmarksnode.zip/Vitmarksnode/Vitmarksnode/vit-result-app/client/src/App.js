import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [results, setResults] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3001/results')
      .then(res => setResults(res.data))
      .catch(err => console.error(err));
  }, []);

  const appStyle = {
    textAlign: 'center',
    fontFamily: 'Arial, sans-serif',
    backgroundColor: '#f0f2f5',
    minHeight: '100vh',
    padding: '20px'
  };

  const tableContainerStyle = {
    display: 'flex',
    justifyContent: 'center',
    marginTop: '20px'
  };

  const tableStyle = {
    borderCollapse: 'collapse',
    width: '90%',
    maxWidth: '900px',
    backgroundColor: 'white',
    boxShadow: '0 0 10px rgba(0,0,0,0.1)'
  };

  const thStyle = {
    backgroundColor: '#007bff',
    color: 'white',
    padding: '10px',
    border: '1px solid #ccc'
  };

  const tdStyle = {
    padding: '10px',
    border: '1px solid #ccc',
    textAlign: 'center'
  };

  return (
    <div style={appStyle}>
      <h1>VIT Student Semester Result</h1>
      <div style={tableContainerStyle}>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>Roll No</th>
              <th style={thStyle}>Name</th>
              <th style={thStyle}>Subject</th>
              <th style={thStyle}>MSE (30%)</th>
              <th style={thStyle}>ESE (70%)</th>
              <th style={thStyle}>Total</th>
            </tr>
          </thead>
          <tbody>
            {results.map((row, index) => (
              <tr key={index}>
                <td style={tdStyle}>{row.roll_number}</td>
                <td style={tdStyle}>{row.name}</td>
                <td style={tdStyle}>{row.subject}</td>
                <td style={tdStyle}>{row.mse_marks}</td>
                <td style={tdStyle}>{row.ese_marks}</td>
                <td style={tdStyle}>{row.total_marks}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default App;
