CREATE DATABASE vit_results;

USE vit_results;

CREATE TABLE students (
  student_id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100),
  roll_number VARCHAR(50) UNIQUE
);

CREATE TABLE mse (
  mse_id INT PRIMARY KEY AUTO_INCREMENT,
  student_id INT,
  subject VARCHAR(50),
  marks INT,
  FOREIGN KEY (student_id) REFERENCES students(student_id)
);

CREATE TABLE ese (
  ese_id INT PRIMARY KEY AUTO_INCREMENT,
  student_id INT,
  subject VARCHAR(50),
  marks INT,
  FOREIGN KEY (student_id) REFERENCES students(student_id)
);


INSERT INTO students (name, roll_number) VALUES
('Sneha Bhat', '21BCE1001'),
('Ravi Kumar', '21BCE1002');

INSERT INTO mse (student_id, subject, marks) VALUES
(1, 'Maths', 25), (1, 'Physics', 22), (1, 'Chemistry', 28), (1, 'Computer', 30),
(2, 'Maths', 20), (2, 'Physics', 26), (2, 'Chemistry', 24), (2, 'Computer', 29);

INSERT INTO ese (student_id, subject, marks) VALUES
(1, 'Maths', 65), (1, 'Physics', 70), (1, 'Chemistry', 68), (1, 'Computer', 75),
(2, 'Maths', 60), (2, 'Physics', 72), (2, 'Chemistry', 66), (2, 'Computer', 74);
