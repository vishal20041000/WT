package Bookstore.bookstore.Repository;



import org.springframework.data.jpa.repository.JpaRepository;
import Bookstore.bookstore.Models.Book;

public interface BookRepository extends JpaRepository<Book, Long> {

    Object findByUsername(String username);
    // add custom queries if needed
}

