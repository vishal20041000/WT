package Bookstore.bookstore.Controller;

import java.util.List;

import org.springframework.http.StreamingHttpOutputMessage.Body;

public class BookRepository {

    public List<Body> findAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

}
