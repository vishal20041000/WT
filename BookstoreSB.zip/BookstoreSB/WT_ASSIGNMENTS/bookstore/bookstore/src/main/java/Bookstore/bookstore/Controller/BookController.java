package Bookstore.bookstore.Controller;
import Bookstore.bookstore.Models.Book;
import Bookstore.bookstore.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.StreamingHttpOutputMessage.Body;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
@CrossOrigin
public class BookController {

    
    @Autowired
    private BookRepository bookRepository;
    

    @GetMapping
    public List<Book> getBooks() {
        return bookRepository.findAll();
    }
}

