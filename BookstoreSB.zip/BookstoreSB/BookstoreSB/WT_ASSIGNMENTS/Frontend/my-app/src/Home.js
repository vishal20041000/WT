export default function Home() {
    return (
      <div className="text-center py-5">
        <h1>Welcome to Book Store 📚</h1>
        <p className="lead">Find your next great read.</p>
      </div>
    );
  }
  