import { useEffect, useState } from "react";
import axios from "axios";

export default function Catalogue() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get("http://localhost:8080/api/books")
      .then((res) => setBooks(res.data))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <p className="text-center py-10">Loading books…</p>;
  }

  if (books.length === 0) {
    return (
      <div className="text-center py-10">
        <h2 className="text-2xl font-semibold mb-4">No books found</h2>
        <p>Our catalogue is empty right now. Please check back later!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4">
      {books.map((book) => (
        <div key={book.bookId} className="border p-4 rounded shadow">
          <img
            src={book.imageUrl || "https://via.placeholder.com/150"}
            alt={book.bookName}
            className="w-full h-40 object-cover mb-2"
          />
          <h2 className="font-bold">{book.bookName}</h2>
          <p>{book.authors}</p>
          <p>${book.price?.toFixed(2)}</p>
        </div>
      ))}
    </div>
  );
}
