import { useState } from 'react';
import axios from 'axios';
import { Form, Button, Card } from 'react-bootstrap';

export default function Register() {
  const [form, setForm] = useState({ username: '', password: '', email: '' });

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8080/api/auth/register', form);
      alert('Registration successful');
    } catch {
      alert('Error during registration');
    }
  };

  return (
    <Card className="mx-auto" style={{ maxWidth: 400 }}>
      <Card.Body>
        <Card.Title>Register</Card.Title>
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Username</Form.Label>
            <Form.Control 
              type="text" 
              onChange={e => setForm({ ...form, username: e.target.value })}
              required 
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Email</Form.Label>
            <Form.Control 
              type="email" 
              onChange={e => setForm({ ...form, email: e.target.value })}
              required 
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Password</Form.Label>
            <Form.Control 
              type="password" 
              onChange={e => setForm({ ...form, password: e.target.value })}
              required 
            />
          </Form.Group>
          <Button variant="success" type="submit" className="w-100">
            Register
          </Button>
        </Form>
      </Card.Body>
    </Card>
  );
}
