package Bookstore.bookstore.Models;

import jakarta.persistence.*;

@Entity
@Table(name = "books")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "book_id")
    private Long bookId;

    @Column(name = "book_name")
    private String bookName;

    @Column(name = "authors")
    private String authors;

    @Column(name = "publications")
    private String publications;

    @Column(name = "price")
    private Double price;

    @Column(name = "catalogue_id")
    private String catalogueId;

    public Book() {}

    public Book(String bookName, String authors, String publications, Double price, String catalogueId) {
        this.bookName = bookName;
        this.authors = authors;
        this.publications = publications;
        this.price = price;
        this.catalogueId = catalogueId;
    }

    // Getters and Setters
    public Long getBookId() { return bookId; }
    public void setBookId(Long bookId) { this.bookId = bookId; }

    public String getBookName() { return bookName; }
    public void setBookName(String bookName) { this.bookName = bookName; }

    public String getAuthors() { return authors; }
    public void setAuthors(String authors) { this.authors = authors; }

    public String getPublications() { return publications; }
    public void setPublications(String publications) { this.publications = publications; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public String getCatalogueId() { return catalogueId; }
    public void setCatalogueId(String catalogueId) { this.catalogueId = catalogueId; }
}


/*
 * INSERT INTO books (book_name, authors, publications, price, catalogue_id) VALUES
('Clean Code', 'Robert C. Martin', 'Prentice Hall', 40.00, 'CAT001'),
('Effective Java', 'Joshua Bloch', 'Addison-Wesley', 45.50, 'CAT002'),
('Java Concurrency in Practice', 'Brian Goetz', 'Addison-Wesley', 50.00, 'CAT003');

 */