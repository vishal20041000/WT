package Bookstore.bookstore.Repository;

import Bookstore.bookstore.Models.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {
    List<Book> findByAuthors(String authors);
}
