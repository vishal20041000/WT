<?php
session_start();
require "config.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $message = "Passwords do not match!";
    } else {
        // Check if username or email exists
        $stmt = $conn->prepare("SELECT consumer_id FROM consumer WHERE username=? OR email=?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "Username or email already taken.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO consumer (username, password, email) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $hash, $email);

            if ($stmt->execute()) {
                $_SESSION['username'] = $username;
                header("Location: index.php");
                exit;
            } else {
                $message = "Error while registering.";
            }
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Register - Grocery Shop</title>
<style>
  body {font-family: Arial, sans-serif; padding: 20px;}
  form {max-width: 400px; margin: auto;}
  input[type=text], input[type=email], input[type=password] {
    width: 100%; padding: 8px; margin: 6px 0 12px 0; box-sizing: border-box;
  }
  input[type=submit] {
    background-color: #4CAF50; color: white; border: none; padding: 10px;
    cursor: pointer; width: 100%;
  }
  .message {color: red; margin-bottom: 15px;}
</style>
</head>
<body>

<h2>Register</h2>
<?php if($message): ?>
    <p class="message"><?php echo htmlspecialchars($message); ?></p>
<?php endif; ?>

<form method="POST" action="">
  <label>Username</label>
  <input type="text" name="username" required />

  <label>Email</label>
  <input type="email" name="email" required />

  <label>Password</label>
  <input type="password" name="password" required />

  <label>Confirm Password</label>
  <input type="password" name="confirm_password" required />

  <input type="submit" value="Register" />
</form>

<p><a href="login.php">Already have an account? Login here.</a></p>

</body>
</html>
