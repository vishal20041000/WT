-- Create database
CREATE DATABASE grocery_shop;

-- Use the database
USE grocery_shop;

-- Consumer table
CREATE TABLE consumer (
    consumer_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
);

-- Items table
CREATE TABLE items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    price DECIMAL(8,2),
    stock INT,
    description TEXT
);

-- Insert sample consumers
INSERT INTO consumer (username, password, email) VALUES
('alice', '$2y$10$KdRZbQb/MKf8.kv6qR2/7OyS0MPb2tg6W3iVffXzLtCAljpmyQF3e', 'alice@example.com'), -- password: alice123
('bob', '$2y$10$bl3dOaDxNsI8xgVpErN2YOwMY23ykJzvDzxPM6X0cw5epMdzOFh/a', 'bob@example.com');    -- password: bob123

-- Insert sample items
INSERT INTO items (name, category, price, stock, description) VALUES
('Apple', 'Fruits', 1.20, 100, 'Fresh red apples'),
('Banana', 'Fruits', 0.50, 150, 'Sweet bananas'),
('Carrot', 'Vegetables', 0.70, 80, 'Organic carrots'),
('Milk', 'Dairy', 1.00, 50, '1-liter fresh milk'),
('Bread', 'Bakery', 2.00, 30, 'Whole wheat bread');
