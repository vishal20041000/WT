<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Online Grocery Shop</title>
<style>
  body {font-family: Arial, sans-serif; margin: 0; padding: 0;}
  header {background-color: #4CAF50; padding: 15px; color: white;}
  nav a {color: white; margin: 0 15px; text-decoration: none;}
  .container {padding: 20px;}
  footer {text-align: center; padding: 10px; background: #ddd; margin-top: 30px;}
</style>
</head>
<body>

<header>
  <h1>Welcome to Online Grocery Shop</h1>
  <nav>
    <a href="index.php">Home</a>
    <?php if(isset($_SESSION['username'])): ?>
      <a href="catalogue.php">Catalogue</a>
      <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
    <?php else: ?>
      <a href="login.php">Login</a>
      <a href="register.php">Register</a>
    <?php endif; ?>
  </nav>
</header>

<div class="container">
  <h2>Fresh groceries delivered to your doorstep!</h2>
  <p>Explore a wide range of fresh fruits, vegetables, dairy products, bakery, and more.</p>
</div>

<footer>
  &copy; <?php echo date("Y"); ?> Online Grocery Shop
</footer>

</body>
</html>
