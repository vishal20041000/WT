<?php
$host = "localhost";
$user = "root";
$pass = "Sncoll22bh";   // Your MySQL password here
$dbname = "grocery_shop";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
