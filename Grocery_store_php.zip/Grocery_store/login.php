<?php
session_start();
require "config.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT password FROM consumer WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($hash);
    if ($stmt->fetch()) {
        if (password_verify($password, $hash)) {
            $_SESSION['username'] = $username;
            header("Location: index.php");
            exit;
        } else {
            $message = "Invalid username or password.";
        }
    } else {
        $message = "Invalid username or password.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Login - Grocery Shop</title>
<style>
  body {font-family: Arial, sans-serif; padding: 20px;}
  form {max-width: 400px; margin: auto;}
  input[type=text], input[type=password] {
    width: 100%; padding: 8px; margin: 6px 0 12px 0; box-sizing: border-box;
  }
  input[type=submit] {
    background-color: #4CAF50; color: white; border: none; padding: 10px;
    cursor: pointer; width: 100%;
  }
  .message {color: red; margin-bottom: 15px;}
</style>
</head>
<body>

<h2>Login</h2>
<?php if($message): ?>
    <p class="message"><?php echo htmlspecialchars($message); ?></p>
<?php endif; ?>

<form method="POST" action="">
  <label>Username</label>
  <input type="text" name="username" required />

  <label>Password</label>
  <input type="password" name="password" required />

  <input type="submit" value="Login" />
</form>

<p><a href="register.php">Don't have an account? Register here.</a></p>

</body>
</html>
