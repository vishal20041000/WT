<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
require "config.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Catalogue - Grocery Shop</title>
<style>
  body {font-family: Arial, sans-serif; margin: 0; padding: 0;}
  header {background-color: #4CAF50; padding: 15px; color: white;}
  nav a {color: white; margin: 0 15px; text-decoration: none;}
  .container {padding: 20px; display: flex; flex-wrap: wrap; gap: 15px;}
  .item {
    border: 1px solid #ccc; border-radius: 5px; padding: 10px;
    width: 220px; box-shadow: 1px 1px 4px #aaa;
  }
  .item h3 {margin-top: 0;}
  .price {color: green; font-weight: bold;}
  .stock {font-size: 0.9em; color: #555;}
  footer {text-align: center; padding: 10px; background: #ddd; margin-top: 30px;}
</style>
</head>
<body>

<header>
  <h1>Grocery Catalogue</h1>
  <nav>
    <a href="index.php">Home</a>
    <a href="catalogue.php">Catalogue</a>
    <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
  </nav>
</header>

<div class="container">
<?php
$sql = "SELECT * FROM items WHERE stock > 0 ORDER BY category, name";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($item = $result->fetch_assoc()) {
        echo '<div class="item">';
        echo '<h3>' . htmlspecialchars($item['name']) . '</h3>';
        echo '<p><strong>Category:</strong> ' . htmlspecialchars($item['category']) . '</p>';
        echo '<p class="price">Price: $' . number_format($item['price'], 2) . '</p>';
        echo '<p class="stock">Stock: ' . $item['stock'] . '</p>';
        echo '<p>' . htmlspecialchars($item['description']) . '</p>';
        echo '</div>';
    }
} else {
    echo '<p>No items available.</p>';
}
?>
</div>

<footer>
  &copy; <?php echo date("Y"); ?> Online Grocery Shop
</footer>

</body>
</html>
