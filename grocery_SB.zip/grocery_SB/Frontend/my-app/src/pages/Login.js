// src/pages/Login.jsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function Login() {
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => setCredentials({ ...credentials, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const res = await axios.post('http://localhost:8080/api/consumers/login', credentials);
      if (res.data.success) {
        alert(res.data.message || 'Login successful!');
        navigate('/home');
      } else {
        setError(res.data.message || 'Invalid email or password');
      }
    } catch (err) {
      setError('Login failed. Please try again.');
    }
  };

  return (
    <div style={styles.container}>
      <form onSubmit={handleSubmit} style={styles.form}>
        <h2 style={styles.title}>Login</h2>
        {error && <p style={styles.error}>{error}</p>}
        <input
          style={styles.input}
          type="email"
          name="email"
          placeholder="Email"
          value={credentials.email}
          onChange={handleChange}
          required
        />
        <input
          style={styles.input}
          type="password"
          name="password"
          placeholder="Password"
          value={credentials.password}
          onChange={handleChange}
          required
        />
        <button type="submit" style={styles.button}>Login</button>
      </form>
    </div>
  );
}

const styles = {
  container: {
    display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh',
    background: '#f0f4f8',
  },
  form: {
    background: '#fff', padding: 30, borderRadius: 8, boxShadow: '0 0 15px rgba(0,0,0,0.15)', width: '300px',
    display: 'flex', flexDirection: 'column',
  },
  title: { marginBottom: 20, textAlign: 'center', color: '#444' },
  input: {
    marginBottom: 15, padding: 10, fontSize: 16, borderRadius: 4,
    border: '1px solid #bbb', outline: 'none',
  },
  button: {
    backgroundColor: '#1976d2', color: 'white', padding: 10, border: 'none', borderRadius: 4,
    cursor: 'pointer', fontWeight: 'bold',
  },
  error: { color: 'red', marginBottom: 15, textAlign: 'center' },
};

export default Login;
