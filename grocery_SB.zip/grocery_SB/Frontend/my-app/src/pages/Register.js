// src/pages/Register.jsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function Register() {
  const [user, setUser] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => setUser({ ...user, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await axios.post('http://localhost:8080/api/consumers', user);
      alert('Registered successfully!');
      navigate('/login');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Try again.');
    }
  };

  return (
    <div style={styles.container}>
      <form onSubmit={handleSubmit} style={styles.form}>
        <h2 style={styles.title}>Register</h2>
        {error && <p style={styles.error}>{error}</p>}
        <input
          style={styles.input}
          type="text"
          name="name"
          placeholder="Name"
          value={user.name}
          onChange={handleChange}
          required
        />
        <input
          style={styles.input}
          type="email"
          name="email"
          placeholder="Email"
          value={user.email}
          onChange={handleChange}
          required
        />
        <input
          style={styles.input}
          type="password"
          name="password"
          placeholder="Password"
          value={user.password}
          onChange={handleChange}
          required
        />
        <button type="submit" style={styles.button}>Register</button>
      </form>
    </div>
  );
}

const styles = {
  container: {
    display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh',
    background: '#f7f9fc',
  },
  form: {
    background: '#fff', padding: 30, borderRadius: 8, boxShadow: '0 0 10px rgba(0,0,0,0.1)', width: '300px',
    display: 'flex', flexDirection: 'column',
  },
  title: { marginBottom: 20, textAlign: 'center', color: '#333' },
  input: {
    marginBottom: 15, padding: 10, fontSize: 16, borderRadius: 4,
    border: '1px solid #ccc', outline: 'none',
  },
  button: {
    backgroundColor: '#4CAF50', color: 'white', padding: 10, border: 'none', borderRadius: 4,
    cursor: 'pointer', fontWeight: 'bold',
  },
  error: { color: 'red', marginBottom: 15, textAlign: 'center' },
};

export default Register;
