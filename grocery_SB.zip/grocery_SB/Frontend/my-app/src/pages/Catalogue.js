import { useEffect, useState } from 'react';
import axios from 'axios';

function Catalogue() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/api/items').then((res) => setItems(res.data));
  }, []);

  return (
    <div>
      <h2>Item Catalogue</h2>
      <ul>
        {items.map(item => <li key={item.id}>{item.name} - ${item.price}</li>)}
      </ul>
    </div>
  );
}
export default Catalogue;
