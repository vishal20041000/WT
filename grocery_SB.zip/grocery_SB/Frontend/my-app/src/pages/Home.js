import { useEffect, useState } from 'react';
import axios from 'axios';

function Home() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchItems() {
      try {
        const res = await axios.get('http://localhost:8080/api/items');
        setItems(res.data);
      } catch (err) {
        setError('Failed to load items');
      } finally {
        setLoading(false);
      }
    }
    fetchItems();
  }, []);

  if (loading) return <p style={styles.message}>Loading items...</p>;
  if (error) return <p style={{ ...styles.message, color: 'red' }}>{error}</p>;

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Welcome to Grocery Shop 🛒</h2>
      <div style={styles.grid}>
        {items.map((item) => (
          <div key={item.id} style={styles.card}>
            <h3>{item.name}</h3>
            <p>Price: ${item.price.toFixed(2)}</p>
            {item.description && <p>{item.description}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '900px',
    margin: '0 auto',
  },
  title: {
    textAlign: 'center',
    color: '#2e7d32',
    marginBottom: '20px',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '20px',
  },
  card: {
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '15px',
    backgroundColor: '#fff',
    boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
  },
  message: {
    textAlign: 'center',
    marginTop: '50px',
    fontSize: '18px',
  },
};

export default Home;
