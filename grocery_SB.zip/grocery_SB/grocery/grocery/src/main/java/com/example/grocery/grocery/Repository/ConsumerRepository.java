package com.example.grocery.grocery.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.grocery.grocery.Model.Consumer;

public interface ConsumerRepository extends JpaRepository<Consumer, Long> {
    Consumer findByEmail(String email);
}



