package com.example.grocery.grocery.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.grocery.grocery.Model.Consumer;
import com.example.grocery.grocery.Model.Item;
import com.example.grocery.grocery.Repository.ConsumerRepository;
import com.example.grocery.grocery.Repository.ItemRepository;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api")
public class GroceryController {

    @Autowired
    private ConsumerRepository consumerRepo;

    @Autowired
    private ItemRepository itemRepo;

    // Used by registration form
    @PostMapping("/consumers")
    public Consumer register(@RequestBody Consumer consumer) {
        return consumerRepo.save(consumer);
    }

    // Used by login form
    @PostMapping("/consumers/login")
public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> loginData) {
    String email = loginData.get("email");
    String password = loginData.get("password");

    System.out.println("Login attempt: email=" + email + ", password=" + password);

    Consumer user = consumerRepo.findByEmail(email);
    System.out.println("Found user: " + user);

    if (user != null) {
        System.out.println("Stored password: " + user.getPassword());
        if (user.getPassword().equals(password)) {
            return ResponseEntity.ok(Map.of("success", true, "message", "Login successful"));
        }
    }

    return ResponseEntity.status(401).body(Map.of("success", false, "message", "Invalid credentials"));
}



    // Load items for catalogue
    @GetMapping("/items")
    public List<Item> getItems() {
        return itemRepo.findAll();
    }
}
