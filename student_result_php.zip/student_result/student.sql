INSERT INTO students VALUES (101, 'Sneha Bhat'), (102, 'Aryan Mehta');

INSERT INTO mse VALUES 
(101, 'Math', 25), (101, 'Physics', 28), (101, 'Chemistry', 26), (101, 'English', 30),
(102, 'Math', 20), (102, 'Physics', 22), (102, 'Chemistry', 24), (102, 'English', 18);

INSERT INTO ese VALUES 
(101, 'Math', 60), (101, 'Physics', 65), (101, 'Chemistry', 58), (101, 'English', 70),
(102, 'Math', 55), (102, 'Physics', 48), (102, 'Chemistry', 50), (102, 'English', 45);
