<?php
$host = "localhost";
$user = "root";
$pass = "Sncoll22bh"; // use your MySQL root password if set
$dbname = "vitresult";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_id = $_GET['student_id'] ?? 0;

$subjects = ['Math', 'Physics', 'Chemistry', 'English'];
$output = "";

// Get student name
$student_sql = "SELECT name FROM students WHERE student_id = $student_id";
$student_result = $conn->query($student_sql);

if ($student_result->num_rows == 0) {
    echo "No student found with ID $student_id";
    exit();
}
$student = $student_result->fetch_assoc();
$output .= "<h3>Result for: {$student['name']} (ID: $student_id)</h3>";
$output .= "<table><tr><th>Subject</th><th>MSE Marks (30%)</th><th>ESE Marks (70%)</th><th>Total</th></tr>";

$total_score = 0;
foreach ($subjects as $subj) {
    $mse_sql = "SELECT marks FROM mse WHERE student_id = $student_id AND subject = '$subj'";
    $ese_sql = "SELECT marks FROM ese WHERE student_id = $student_id AND subject = '$subj'";

    $mse_marks = $conn->query($mse_sql)->fetch_assoc()['marks'] ?? 0;
    $ese_marks = $conn->query($ese_sql)->fetch_assoc()['marks'] ?? 0;

    $final = round(($mse_marks * 0.3) + ($ese_marks * 0.7), 2);
    $total_score += $final;

    $output .= "<tr>
        <td>$subj</td>
        <td>$mse_marks</td>
        <td>$ese_marks</td>
        <td>$final</td>
    </tr>";
}
$avg = round($total_score / count($subjects), 2);
$output .= "<tr><td colspan='3'><b>Average</b></td><td><b>$avg</b></td></tr>";
$output .= "</table>";

echo $output;
$conn->close();
?>
