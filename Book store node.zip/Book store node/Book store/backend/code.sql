CREATE DATABASE bookstore_db;

USE bookstore_db;

CREATE TABLE Books (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100),
    author VARCHAR(100),
    price DECIMAL(10,2),
    description TEXT,
    image VARCHAR(255)
);

INSERT INTO Books (title, author, price, description, image)
VALUES
('The Alchemist', 'Paulo Coelho', 299.00, 'A philosophical story about finding one’s destiny.', 'https://m.media-amazon.com/images/I/51Z0nLAfLmL.jpg'),
('Atomic Habits', 'James Clear', 449.00, 'An easy & proven way to build good habits.', 'https://m.media-amazon.com/images/I/91bYsX41DVL.jpg'),
('Rich Dad Poor Dad', 'Robert T. Kiyosaki', 350.00, 'A personal finance classic.', 'https://m.media-amazon.com/images/I/81BE7eeKzAL.jpg');
