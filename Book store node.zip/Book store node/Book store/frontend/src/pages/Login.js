import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    // Dummy check (you can connect to DB here)
    if (username === 'admin' && password === '1234') {
      alert('Login Successful!');
      navigate('/catalogue');
    } else {
      alert('Invalid credentials');
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <input value={username} onChange={(e) => setUsername(e.target.value)} type="text" placeholder="Username" required /><br/><br/>
        <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="Password" required /><br/><br/>
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default Login;
