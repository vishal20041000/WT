function Home() {
  return <h2>Welcome to the Online Bookstore</h2>;
}

export default Home;
