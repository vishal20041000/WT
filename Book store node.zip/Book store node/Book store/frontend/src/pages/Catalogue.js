import { useEffect, useState } from 'react';
import axios from 'axios';
import './Catalogue.css'; // Create this CSS file

function Catalogue() {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/books')
      .then(response => setBooks(response.data))
      .catch(error => console.error(error));
  }, []);

  return (
    <div className="catalogue-container">
      {books.map(book => (
        <div key={book.id} className="book-card">
          <img src={book.image} alt={book.title} />
          <div className="book-info">
            <h3>{book.title}</h3>
            <p><strong>Author:</strong> {book.author}</p>
            <p><strong>₹{book.price}</strong></p>
            <p>{book.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

export default Catalogue;
